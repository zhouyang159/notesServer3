create definer = dk@`%` view all_user as
select `test1`.`tablea`.`id`        AS `id`,
       `test1`.`tablea`.`name`      AS `name`,
       `test1`.`tablea`.`date`      AS `date`,
       `test1`.`tablea`.`datetime`  AS `datetime`,
       `test1`.`tablea`.`time`      AS `time`,
       `test1`.`tablea`.`timestamp` AS `timestamp`
from `test1`.`tablea`
union all
select `test1`.`tableb`.`id`        AS `id`,
       `test1`.`tableb`.`name`      AS `name`,
       `test1`.`tableb`.`date`      AS `date`,
       `test1`.`tableb`.`datetime`  AS `datetime`,
       `test1`.`tableb`.`time`      AS `time`,
       `test1`.`tableb`.`timestamp` AS `timestamp`
from `test1`.`tableb`;

